﻿using System;
using LinkedListHelper;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Text;

namespace UnitTestLinkedListHelper
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            //Arrange
           Node rv;
          LinkedListHelper.LinkedListHelper lsh=new LinkedListHelper.LinkedListHelper();
          string sb = "EBEBA";
          Node root=  new Node("E");
          Node Node1=new Node("B");
          Node Node2 = new Node("E");
          Node Node3 = new Node("E");
          Node Node4 = new Node("B");
          Node Node5 = new Node("A");
          Node Node6 = new Node("B");
          root.next = Node1;
          Node1.previous = root;
          Node1.next = Node2;
          Node2.previous = Node1;
          Node2.next = Node3;
          Node3.previous = Node2;
          Node3.next = Node4;
          Node4.previous = Node3;
          Node4.next = Node5;
          Node5.previous = Node4;
          Node5.next = Node6;
          Node6.previous = Node5;
            //Acct
            lsh.DeleteNodesWithValuesMoreThan2Times(root, out rv);
           string data=lsh.GetLinkedListValues(rv);
           //Assert
           Assert.AreEqual(data,sb);

        }
    }
}
