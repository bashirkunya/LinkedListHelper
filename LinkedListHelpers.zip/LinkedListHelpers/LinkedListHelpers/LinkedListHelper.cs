﻿using System;
using System.Collections.Generic;

namespace LinkedListHelper
{
    public class LinkedListHelper
    {
        int value;
        string linkedListValues = string.Empty;
        private Node rootNode = null;
        Node root1;
        int count = 0;
        IDictionary<string, int> dictionary = new Dictionary<string, int>();
        public void DeleteNodesWithValuesMoreThan2Times(Node root,out Node rootNode)
        {
            try
            {

                if (count == 0) root1 = root;
                if (dictionary.ContainsKey(root.data))
                {
                    dictionary.TryGetValue(root.data, out value);
                    if (value >= 2)
                    {
                        //root.previous = root.next.previous;
                        root.previous.next = root.next;
                        if (root.next == null)
                        {
                            rootNode = root1;
                            return;
                        }

                    }

                    dictionary[root.data] = value + 1;
                }
                else
                {
                    dictionary.Add(root.data, 1);
                }

                count++;
                DeleteNodesWithValuesMoreThan2Times(root.next, out rootNode);
            }
            catch (Exception e)
            {
                rootNode = root1;
            }
        }

        public  string GetLinkedListValues(Node root)
        {
            linkedListValues += root.data;
            if (root.next != null)
            {
                GetLinkedListValues(root.next);
            }

            return linkedListValues;
        }
    }
    public class Node
    {
        public string data { get; set; }
        public Node previous { get; set; }
        public Node next { get; set; }
        public Node(string d)
        {
            data = d;
            previous = null;
            next = null;
        }
    }
}
